#include <stdint.h>

uint16_t byte_compress( uint8_t *data_ptr, uint16_t size);