#include <stdio.h>
#include <stdint.h>
#include "compress.h"
#include "decompress.h"

uint8_t data_ptr[] = {
    0x03, 0x74, 0x04, 0x04, 0x04, 0x35, 0x35, 0x64,
    0x64, 0x64, 0x64, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x56, 0x45, 0x56, 0x56, 0x56, 0x09, 0x09, 0x09
};

int main()
{
    uint16_t size, i; 
    
    size = byte_compress(data_ptr, sizeof(data_ptr));
    
    for (i =0; i < size; i++)
    {
        printf("  0x%x",data_ptr[i]);
    }
    
    printf("\n\n");
    
    printf("%d", sizeof(data_ptr));
        printf("\n\n");
    size = byte_decompress(data_ptr, size);
    for (i =0; i < size; i++)
    {
        printf("  0x%x",data_ptr[i]);
    }

	while (1);
}