#include <stdint.h>

uint16_t byte_decompress( uint8_t *data_ptr, uint16_t size);